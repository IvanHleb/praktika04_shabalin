﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Airport_Shabalin
{
	public partial class Autorisation : Form
	{
		public Autorisation()
		{
			InitializeComponent();

		}

		static string connectionstring;
		string username = "st2996";
		string password = "pwd2996";
		string DB_name = "shabalin_pm11_31";
		string host = "172.20.7.6";
		private void Login_button_Click(object sender, EventArgs e)
		{
			NpgsqlConnection con = new NpgsqlConnection(connectionstring);
			try
			{
				connectionstring = $"Host={host};Port=5432;Username={Login_textBox.Text};Password={Password_textBox.Text};Database={DB_name};";
				con = new NpgsqlConnection(connectionstring);
				con.Open();
				Main_Form main = new Main_Form(connectionstring, "admin");
				main.Show();
				this.Hide();
				return;
			}
			catch
			{
				connectionstring = $"Host={host};Port=5432;Username={username};Password={password};Database={DB_name};";
				con = new NpgsqlConnection(connectionstring);
				con.Open();
			}

			NpgsqlCommand cmd = new NpgsqlCommand("SELECT User_Login, User_Password, User_role FROM Users", con);
			NpgsqlDataAdapter dataReader = new NpgsqlDataAdapter(cmd);
			DataTable dt = new DataTable();
			dataReader.Fill(dt);

			con.Close();

			DataGridView dgv = new DataGridView();
			this.Controls.Add(dgv);
			dgv.DataSource = dt;
			dgv.Show();

			for (int i = 0; i < dgv.Rows.Count - 1; i++)
			{
				if (Login_textBox.Text == dgv[0, i].Value + "" && Password_textBox.Text == dgv[1, i].Value + "")
				{
					Main_Form main = new Main_Form(connectionstring, dgv[2, i].Value + "");
					main.Show();
					this.Hide();
					return;
				}
				else
				{
					this.Controls.Remove(dgv);
					MessageBox.Show("Неправильный логин или пароль!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					return;
				}
			}

			this.Controls.Remove(dgv);
		}

        private void Login_textBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
