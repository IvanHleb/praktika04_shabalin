﻿namespace Airport_Shabalin
{
	partial class Main_Form
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
            this.Delete_checkBox = new System.Windows.Forms.CheckBox();
            this.Buttons_tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.CHANGE_button = new System.Windows.Forms.Button();
            this.ADD_button = new System.Windows.Forms.Button();
            this.DELETE_button = new System.Windows.Forms.Button();
            this.Filter_panel = new System.Windows.Forms.Panel();
            this.Choose_comboBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Search_Settings_Box = new System.Windows.Forms.ComboBox();
            this.Search_Box = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DB_Tables_comboBox = new System.Windows.Forms.ComboBox();
            this.Delete_table_button = new System.Windows.Forms.Button();
            this.Add_table_button = new System.Windows.Forms.Button();
            this.Tables_TabControl = new System.Windows.Forms.TabControl();
            this.Users = new System.Windows.Forms.TabPage();
            this.Buttons_tableLayoutPanel.SuspendLayout();
            this.Filter_panel.SuspendLayout();
            this.panel3.SuspendLayout();
            this.Tables_TabControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // Delete_checkBox
            // 
            this.Delete_checkBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Delete_checkBox.AutoSize = true;
            this.Delete_checkBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Delete_checkBox.ForeColor = System.Drawing.Color.White;
            this.Delete_checkBox.Location = new System.Drawing.Point(3, 113);
            this.Delete_checkBox.Name = "Delete_checkBox";
            this.Delete_checkBox.Size = new System.Drawing.Size(225, 28);
            this.Delete_checkBox.TabIndex = 45;
            this.Delete_checkBox.Text = "Удаление по фильтру";
            this.Delete_checkBox.UseVisualStyleBackColor = true;
            // 
            // Buttons_tableLayoutPanel
            // 
            this.Buttons_tableLayoutPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Buttons_tableLayoutPanel.ColumnCount = 3;
            this.Buttons_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.Buttons_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.Buttons_tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.Buttons_tableLayoutPanel.Controls.Add(this.CHANGE_button, 0, 0);
            this.Buttons_tableLayoutPanel.Controls.Add(this.ADD_button, 0, 0);
            this.Buttons_tableLayoutPanel.Controls.Add(this.DELETE_button, 2, 0);
            this.Buttons_tableLayoutPanel.Location = new System.Drawing.Point(29, 635);
            this.Buttons_tableLayoutPanel.Name = "Buttons_tableLayoutPanel";
            this.Buttons_tableLayoutPanel.RowCount = 1;
            this.Buttons_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.Buttons_tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 78F));
            this.Buttons_tableLayoutPanel.Size = new System.Drawing.Size(314, 78);
            this.Buttons_tableLayoutPanel.TabIndex = 44;
            // 
            // CHANGE_button
            // 
            this.CHANGE_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CHANGE_button.BackColor = System.Drawing.Color.White;
            this.CHANGE_button.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.CHANGE_button.Font = new System.Drawing.Font("Onyx", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CHANGE_button.ForeColor = System.Drawing.Color.Black;
            this.CHANGE_button.Location = new System.Drawing.Point(107, 3);
            this.CHANGE_button.Name = "CHANGE_button";
            this.CHANGE_button.Size = new System.Drawing.Size(98, 67);
            this.CHANGE_button.TabIndex = 20;
            this.CHANGE_button.Text = "Изменить";
            this.CHANGE_button.UseVisualStyleBackColor = false;
            this.CHANGE_button.Click += new System.EventHandler(this.CHANGE_button_Click);
            // 
            // ADD_button
            // 
            this.ADD_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ADD_button.BackColor = System.Drawing.Color.White;
            this.ADD_button.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.ADD_button.Font = new System.Drawing.Font("Onyx", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ADD_button.ForeColor = System.Drawing.Color.Black;
            this.ADD_button.Location = new System.Drawing.Point(3, 3);
            this.ADD_button.Name = "ADD_button";
            this.ADD_button.Size = new System.Drawing.Size(98, 67);
            this.ADD_button.TabIndex = 0;
            this.ADD_button.Text = "Добавить";
            this.ADD_button.UseVisualStyleBackColor = false;
            this.ADD_button.Click += new System.EventHandler(this.ADD_button_Click);
            // 
            // DELETE_button
            // 
            this.DELETE_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DELETE_button.BackColor = System.Drawing.Color.White;
            this.DELETE_button.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.DELETE_button.Font = new System.Drawing.Font("Onyx", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DELETE_button.ForeColor = System.Drawing.Color.Black;
            this.DELETE_button.Location = new System.Drawing.Point(212, 3);
            this.DELETE_button.Name = "DELETE_button";
            this.DELETE_button.Size = new System.Drawing.Size(99, 67);
            this.DELETE_button.TabIndex = 18;
            this.DELETE_button.Text = "Удалить";
            this.DELETE_button.UseVisualStyleBackColor = false;
            this.DELETE_button.Click += new System.EventHandler(this.DELETE_button_Click);
            // 
            // Filter_panel
            // 
            this.Filter_panel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Filter_panel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.Filter_panel.Controls.Add(this.Delete_checkBox);
            this.Filter_panel.Controls.Add(this.Choose_comboBox);
            this.Filter_panel.Controls.Add(this.label6);
            this.Filter_panel.Controls.Add(this.Search_Settings_Box);
            this.Filter_panel.Controls.Add(this.Search_Box);
            this.Filter_panel.Controls.Add(this.label1);
            this.Filter_panel.Location = new System.Drawing.Point(903, 22);
            this.Filter_panel.Name = "Filter_panel";
            this.Filter_panel.Size = new System.Drawing.Size(280, 144);
            this.Filter_panel.TabIndex = 43;
            // 
            // Choose_comboBox
            // 
            this.Choose_comboBox.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Choose_comboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Choose_comboBox.FormattingEnabled = true;
            this.Choose_comboBox.Location = new System.Drawing.Point(143, 32);
            this.Choose_comboBox.Name = "Choose_comboBox";
            this.Choose_comboBox.Size = new System.Drawing.Size(131, 28);
            this.Choose_comboBox.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(3, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 22);
            this.label6.TabIndex = 10;
            this.label6.Text = "Filter";
            // 
            // Search_Settings_Box
            // 
            this.Search_Settings_Box.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Search_Settings_Box.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Search_Settings_Box.FormattingEnabled = true;
            this.Search_Settings_Box.Location = new System.Drawing.Point(7, 32);
            this.Search_Settings_Box.Name = "Search_Settings_Box";
            this.Search_Settings_Box.Size = new System.Drawing.Size(131, 28);
            this.Search_Settings_Box.TabIndex = 4;
            this.Search_Settings_Box.SelectedIndexChanged += new System.EventHandler(this.Search_Settings_Box_SelectedIndexChanged);
            // 
            // Search_Box
            // 
            this.Search_Box.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Search_Box.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Search_Box.Location = new System.Drawing.Point(79, 66);
            this.Search_Box.Name = "Search_Box";
            this.Search_Box.Size = new System.Drawing.Size(195, 29);
            this.Search_Box.TabIndex = 3;
            this.Search_Box.TextChanged += new System.EventHandler(this.Search_Box_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(4, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 24);
            this.label1.TabIndex = 6;
            this.label1.Text = "Поиск";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.DB_Tables_comboBox);
            this.panel3.Controls.Add(this.Delete_table_button);
            this.panel3.Controls.Add(this.Add_table_button);
            this.panel3.Location = new System.Drawing.Point(29, 28);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(715, 78);
            this.panel3.TabIndex = 42;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(530, 44);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(169, 25);
            this.label7.TabIndex = 18;
            this.label7.Text = "Удалить вкладку";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(530, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(182, 25);
            this.label2.TabIndex = 29;
            this.label2.Text = "Добавить вкладку";
            // 
            // DB_Tables_comboBox
            // 
            this.DB_Tables_comboBox.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.DB_Tables_comboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DB_Tables_comboBox.FormattingEnabled = true;
            this.DB_Tables_comboBox.Location = new System.Drawing.Point(3, 4);
            this.DB_Tables_comboBox.Name = "DB_Tables_comboBox";
            this.DB_Tables_comboBox.Size = new System.Drawing.Size(454, 32);
            this.DB_Tables_comboBox.TabIndex = 13;
            // 
            // Delete_table_button
            // 
            this.Delete_table_button.BackColor = System.Drawing.Color.White;
            this.Delete_table_button.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete_table_button.ForeColor = System.Drawing.Color.Black;
            this.Delete_table_button.Location = new System.Drawing.Point(473, 42);
            this.Delete_table_button.Name = "Delete_table_button";
            this.Delete_table_button.Size = new System.Drawing.Size(56, 32);
            this.Delete_table_button.TabIndex = 15;
            this.Delete_table_button.Text = "-";
            this.Delete_table_button.UseVisualStyleBackColor = false;
            this.Delete_table_button.Click += new System.EventHandler(this.Delete_table_button_Click);
            // 
            // Add_table_button
            // 
            this.Add_table_button.BackColor = System.Drawing.Color.White;
            this.Add_table_button.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_table_button.ForeColor = System.Drawing.Color.Black;
            this.Add_table_button.Location = new System.Drawing.Point(473, 4);
            this.Add_table_button.Name = "Add_table_button";
            this.Add_table_button.Size = new System.Drawing.Size(56, 32);
            this.Add_table_button.TabIndex = 14;
            this.Add_table_button.Text = "+";
            this.Add_table_button.UseVisualStyleBackColor = false;
            this.Add_table_button.Click += new System.EventHandler(this.Add_table_button_Click);
            // 
            // Tables_TabControl
            // 
            this.Tables_TabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Tables_TabControl.Controls.Add(this.Users);
            this.Tables_TabControl.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Tables_TabControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Tables_TabControl.Location = new System.Drawing.Point(29, 202);
            this.Tables_TabControl.Multiline = true;
            this.Tables_TabControl.Name = "Tables_TabControl";
            this.Tables_TabControl.SelectedIndex = 0;
            this.Tables_TabControl.Size = new System.Drawing.Size(1158, 430);
            this.Tables_TabControl.TabIndex = 41;
            this.Tables_TabControl.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.Tables_TabControl_Selecting);
            // 
            // Users
            // 
            this.Users.BackColor = System.Drawing.Color.Transparent;
            this.Users.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Users.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Users.Location = new System.Drawing.Point(4, 29);
            this.Users.Name = "Users";
            this.Users.Padding = new System.Windows.Forms.Padding(3);
            this.Users.Size = new System.Drawing.Size(1150, 397);
            this.Users.TabIndex = 0;
            this.Users.Text = "Person";
            // 
            // Main_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 734);
            this.Controls.Add(this.Buttons_tableLayoutPanel);
            this.Controls.Add(this.Filter_panel);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.Tables_TabControl);
            this.Name = "Main_Form";
            this.Text = "Afton_shipping";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Buttons_tableLayoutPanel.ResumeLayout(false);
            this.Filter_panel.ResumeLayout(false);
            this.Filter_panel.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.Tables_TabControl.ResumeLayout(false);
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.CheckBox Delete_checkBox;
		private System.Windows.Forms.TableLayoutPanel Buttons_tableLayoutPanel;
		private System.Windows.Forms.Button CHANGE_button;
		private System.Windows.Forms.Button ADD_button;
		private System.Windows.Forms.Button DELETE_button;
		private System.Windows.Forms.Panel Filter_panel;
		private System.Windows.Forms.ComboBox Choose_comboBox;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ComboBox Search_Settings_Box;
		private System.Windows.Forms.TextBox Search_Box;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox DB_Tables_comboBox;
		private System.Windows.Forms.Button Delete_table_button;
		private System.Windows.Forms.Button Add_table_button;
		private System.Windows.Forms.TabControl Tables_TabControl;
		private System.Windows.Forms.TabPage Users;
	}
}

