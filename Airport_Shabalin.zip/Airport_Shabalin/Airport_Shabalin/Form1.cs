﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Airport_Shabalin
{
	public partial class Main_Form : Form
	{
		public Main_Form(string _connectionstring, string _usertype)
		{
			InitializeComponent();
			
			usertype = _usertype;
			connectionstring = _connectionstring;
            Get_Tables();
        }
		static string usertype;
		static string connectionstring;
		string Current_Table = "";//текущая выбранная таблица

		string Role_Handler(string _querry, string _usertype)
		{
			switch (_usertype)
			{
				case "admin":
					{
						/*
						department
						crew
						aircraft
						employees
						passanger
						flights
						tickets
						 */
					}
					break;
				case "driver":
					{
						/*
						orders
						cargo
						cars
						
						 */
						_querry += " and table_name != 'clients'";
						_querry += " and table_name != 'drivers'";
                        _querry += " and table_name != 'users'";

                        Buttons_tableLayoutPanel.Visible = false;
						Delete_checkBox.Visible = false;	
					}
					break;
				case "pilot":
					{
						/*
						department
						crew
						aircraft
						flights
						 */
						_querry += " and table_name != 'tickets'";
						_querry += " and table_name != 'passanger'";
						_querry += " and table_name != 'employees'";
                        _querry += " and table_name != 'users'";

                        Buttons_tableLayoutPanel.Visible = false;
						Delete_checkBox.Visible = false;
					}
					break;
				case "dispatcher":
					{
						/*
						department
						crew
						aircraft
						flights
						 */
						_querry += " and table_name != 'tickets'";
						_querry += " and table_name != 'passanger'";
						_querry += " and table_name != 'employees'";
                        _querry += " and table_name != 'users'";
                    }
					break;
				default:
					break;
			}


			return _querry;
		}

		void Get_Tables()//получение списка таблиц из базы данных и добавление первой из них
		{
			try
			{
				//Добавление существующих таблиц из ИС
				NpgsqlConnection con = new NpgsqlConnection(connectionstring);


				//MessageBox.Show( con.UserName);
				con.Open();
				string querry = "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE' AND table_name != 'sysdiagrams'";

				querry = Role_Handler(querry, usertype);

				NpgsqlCommand cmd = new NpgsqlCommand(querry, con);
				NpgsqlDataAdapter dataReader = new NpgsqlDataAdapter(cmd);

				DataTable dt = new DataTable();

				dataReader.Fill(dt);
				con.Close();

				DB_Tables_comboBox.DataSource = dt;
				DB_Tables_comboBox.DisplayMember = "TABLE_NAME";
				DB_Tables_comboBox.ValueMember = "TABLE_NAME";
			}
			catch (Exception ex) { MessageBox.Show(ex.Message); }

			Tables_TabControl.TabPages.Clear();


			Tables_TabControl.TabPages.Add(DB_Tables_comboBox.SelectedValue.ToString(), Name = DB_Tables_comboBox.SelectedValue.ToString()); // НАИМЕНОВАНИЕ НАЧАЛЬНОЙ ТАБЛИЦЫ ДЛЯ ОТОБРАЖЕНИЯ 
			try
			{
				Current_Table = Tables_TabControl.SelectedTab.Name;
			}
			catch (Exception ex) { MessageBox.Show(ex.Message); }

			CreateTable();
			RefreshTable();

			//_
		}

		private void ADD_button_Click(object sender, EventArgs e)
		{
			string querry = "INSERT INTO " + Current_Table + " ";

			foreach (var ctrl in Tables_TabControl.SelectedTab.Controls)
			{
				var dgv = ctrl as DataGridView;

				if (dgv != null)
				{
					try
					{
						NpgsqlConnection con = new NpgsqlConnection(connectionstring);

						querry += "(";

						for (int g = 1; g <= dgv.Columns.Count - 1; g++) 
						{
							querry += " " + dgv.Columns[g].Name + ", ";
						}

						querry = querry.Remove(querry.LastIndexOf(","));
						querry += ") ";
						querry += " VALUES ";
						querry += "(";

						for (int g = 1; g <= dgv.Columns.Count - 1; g++) 
						{
							querry += " '" + dgv[g, Convert.ToInt32(dgv.CurrentRow.Index)].Value.ToString() + "',";
						}

						querry = querry.Remove(querry.LastIndexOf(","));
						querry += ") ";
						NpgsqlCommand cmd = new NpgsqlCommand(querry, con);
						NpgsqlDataAdapter dataReader = new NpgsqlDataAdapter(cmd);
						DataTable dt = new DataTable();

						dataReader.Fill(dt);
						con.Close();
						RefreshTable();
						MessageBox.Show("Данные добавлены!");
					}
					catch (Exception ex)
					{
						MessageBox.Show(ex + "");
						RefreshTable();
					}
				}
			}
		}

		private void CHANGE_button_Click(object sender, EventArgs e)
		{
			string querry = "UPDATE  " + Current_Table + " SET ";

			foreach (var ctrl in Tables_TabControl.SelectedTab.Controls)
			{
				var dgv = ctrl as DataGridView;

				if (dgv != null)
				{
					try
					{
						NpgsqlConnection con = new NpgsqlConnection(connectionstring);

						querry += " ";

						for (int g = 1; g <= dgv.Columns.Count - 1; g++)
						{
							querry += " " + dgv.Columns[g].Name + " = " + " '" + dgv[g, Convert.ToInt32(dgv.CurrentRow.Index)].Value.ToString() + "', ";
						}

						querry = querry.Remove(querry.LastIndexOf(","));
						querry += " WHERE " + dgv.Columns[0].Name + " = " + dgv[0, Convert.ToInt32(dgv.CurrentRow.Index)].Value.ToString();
						Clipboard.SetText(querry);
						//MessageBox.Show(querry);
						NpgsqlCommand cmd = new NpgsqlCommand(querry, con);
						NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
						NpgsqlDataAdapter dataReader = new NpgsqlDataAdapter(cmd);
						DataTable dt = new DataTable();

						dataReader.Fill(dt);
						con.Close();

						RefreshTable();
						MessageBox.Show("Данные изменены!");
					}
					catch
					{
						RefreshTable();
					}
				}
			}
		}

		void CreateTable()
		{
			DataGridView dgv = new DataGridView();

			dgv.Show();
			dgv.Dock = DockStyle.Fill;
			dgv.BackgroundColor = this.BackColor;
			Tables_TabControl.SelectedTab.Controls.Add(dgv);
			dgv.GridColor = Color.Black;
			dgv.BorderStyle = BorderStyle.FixedSingle;

			dgv.CellBorderStyle = DataGridViewCellBorderStyle.Sunken;
			dgv.RowsDefaultCellStyle.BackColor = Color.LightBlue;
			dgv.RowsDefaultCellStyle.ForeColor = Color.Black;
			dgv.RowsDefaultCellStyle.SelectionBackColor = Color.LightGreen;
			dgv.RowsDefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));

			dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
			dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightBlue;
			dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
			dgv.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.Black;
			dgv.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));

			dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.White;
			dgv.DefaultCellStyle.BackColor = Color.Black;
			
			dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
			dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dgv.Refresh();
		}

		void RefreshTable()
		{
			NpgsqlConnection con = new NpgsqlConnection(connectionstring);
			con.Open();
			foreach (var ctrl in Tables_TabControl.SelectedTab.Controls)
			{
				var dgv = ctrl as DataGridView;
				if (dgv != null)
				{

					string querry = $"SELECT * FROM {Current_Table}";


					dgv.DataSource = null;

					NpgsqlCommand cmd = new NpgsqlCommand(querry, con);
					NpgsqlDataAdapter dataReader = new NpgsqlDataAdapter(cmd);
					DataTable dt = new DataTable();
					dataReader.Fill(dt);
					dgv.DataSource = dt;

					
					Search_Settings_Box.DataSource = dgv.Columns;


					try
					{
						label6.Text = "Filter ";
						Search_Settings_Box.DisplayMember = "HeaderText";
						Search_Settings_Box.ValueMember = "HeaderText";
					}
					catch (Exception ex) { MessageBox.Show(ex.Message); }

					Search_Settings_Box.SelectionStart = Search_Box.TextLength;
					Search_Box.ScrollToCaret();
				}
				dgv.Refresh();
			}
			con.Close();
		}
		private void DELETE_button_Click(object sender, EventArgs e)
		{
			try
			{
				if (Delete_checkBox.Checked)
				{


					NpgsqlConnection con = new NpgsqlConnection(connectionstring);
					con.Open();
					foreach (var ctrl in Tables_TabControl.SelectedTab.Controls)
					{
						var dgv = ctrl as DataGridView;
						if (dgv != null)
						{
							NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM " + Current_Table + " Where [" + Search_Settings_Box.Text + "] LIKE '%" + Search_Box.Text + "%'", con);
							NpgsqlDataAdapter dataReader = new NpgsqlDataAdapter(cmd);
							DataTable dt = new DataTable();
							dataReader.Fill(dt);

							dgv.DataSource = dt;
							dgv.Refresh();

							RefreshTable();
							MessageBox.Show("Данные удалены!");
						}
					}
					con.Close();

				}
				else
				{
					NpgsqlConnection con = new NpgsqlConnection(connectionstring);
					con.Open();
					foreach (var ctrl in Tables_TabControl.SelectedTab.Controls)
					{
						var dgv = ctrl as DataGridView;
						if (dgv != null)
						{
							string querry = $"DELETE FROM {Current_Table} WHERE {dgv.Columns[0].Name} = '{dgv[0, Convert.ToInt32(dgv.CurrentRow.Index)].Value.ToString()}' ";
							//MessageBox.Show(querry);
							NpgsqlCommand cmd = new NpgsqlCommand(querry, con);
							NpgsqlDataAdapter dataReader = new NpgsqlDataAdapter(cmd);
							DataTable dt = new DataTable();

							dataReader.Fill(dt);

							dgv.DataSource = dt;
							dgv.Refresh();

							RefreshTable();
							MessageBox.Show("Данные удалены!");
						}
					}
					con.Close();
				}

			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}

			if (Search_Box.Text == "")
			{
				RefreshTable();
			}
		}

		private void Add_table_button_Click(object sender, EventArgs e)
		{
			bool cont = false;
			foreach (Control c in Tables_TabControl.Controls)
			{
				if (DB_Tables_comboBox.Text == "" || c.Name.Contains(DB_Tables_comboBox.Text))
				{
					cont = true;
				}
			}

			if (!cont)
			{
				Tables_TabControl.TabPages.Add(DB_Tables_comboBox.Text, Name = DB_Tables_comboBox.Text);
			}
		}

		private void Delete_table_button_Click(object sender, EventArgs e)
		{
			if (Tables_TabControl.TabCount > 1)
			{
				Tables_TabControl.TabPages.Remove(Tables_TabControl.SelectedTab);
			}
		}

		private void Search_Settings_Box_SelectedIndexChanged(object sender, EventArgs e)
		{
			NpgsqlConnection con = new NpgsqlConnection(connectionstring);
			con.Open();
			NpgsqlCommand cmd = new NpgsqlCommand("SELECT * FROM " + Current_Table, con);
			NpgsqlDataAdapter dataReader = new NpgsqlDataAdapter(cmd);
			DataTable dt = new DataTable();
			dataReader.Fill(dt);

			Choose_comboBox.DataSource = dt;
			Choose_comboBox.DisplayMember = Search_Settings_Box.Text;
			Choose_comboBox.ValueMember = dt.Columns[1].ToString();

			Search_Settings_Box.SelectionStart = Search_Box.TextLength;
			Search_Box.ScrollToCaret();
			con.Close();
		}

		private void Search_Box_TextChanged(object sender, EventArgs e)
		{
			try
			{
				NpgsqlConnection con = new NpgsqlConnection(connectionstring);
				con.Open();
				foreach (var ctrl in Tables_TabControl.SelectedTab.Controls)
				{
					var dgv = ctrl as DataGridView;
					if (dgv != null)
					{
						NpgsqlCommand cmd = new NpgsqlCommand("SELECT * FROM " + Current_Table + " Where [" + Search_Settings_Box.Text + "] LIKE '%" + Search_Box.Text + "%'", con);// " + Search_Box.Text, con);//dgv.Columns[i].Name
						NpgsqlDataAdapter dataReader = new NpgsqlDataAdapter(cmd);
						DataTable dt = new DataTable();
						dataReader.Fill(dt);

						dgv.DataSource = dt;
						dgv.Refresh();
					}
				}
				con.Close();
			}
			catch (Exception ex) { MessageBox.Show(ex.Message); }

			if (Search_Box.Text == "")
			{
				RefreshTable();
			}
		}


		private void Tables_TabControl_Selecting(object sender, TabControlCancelEventArgs e)
		{
			try
			{
				Current_Table = Tables_TabControl.SelectedTab.Name;

	

				foreach (var ctrl in Tables_TabControl.SelectedTab.Controls)
				{
					var dgv = ctrl as DataGridView;
					if (dgv != null)
					{

						Tables_TabControl.SelectedTab.Controls.Remove(dgv);
					}
				}
			}
			catch (Exception ex) { MessageBox.Show(ex.Message); }

			CreateTable();
			RefreshTable();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			//Airport_Shabalin
		}
	}
}
