using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace UnitTests.Tests
{
    [TestFixture]
    public class Tests
    {

        private LoginForm _loginForm;

        [SetUp]
        public void Setup()
        {
            _loginForm = new LoginForm();
        }

        [Test]
        public void CorrectLogin()
        {
            string username = "st2996";
            string password = "pwd2996";
            bool isAuthenticated = _loginForm.Authenticate(username, password);
            Assert.IsTrue(isAuthenticated);
        }

        [Test]
        public void IncorrectLogin()
        {
            string username = "st29966";
            string password = "pwd2996";
            bool isAuthenticated = _loginForm.Authenticate(username, password);
            Assert.IsFalse(isAuthenticated);
        }

        internal class LoginForm
        {
            public bool Authenticate(string username, string password)
            {
                return username == "st2996" && password == "pwd2996";
            }
        }
    }
}